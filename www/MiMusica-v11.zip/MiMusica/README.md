# Mi Música v11
- Se quitó la pestaña Explorar (Jamendo). La app queda solo para tu música local (sin internet, sin anuncios).
- Se mantiene: al terminar una lista, la música continúa con otras canciones (se puede desactivar en Ajustes).
Para actualizar: borra JamendoApi.kt del repositorio si lo subiste, sube de nuevo la carpeta `app` y desinstala la versión anterior antes de instalar el nuevo APK.
